"""Select a single best playable source from Otaku-style provider results.

This module ranks source *candidates*. Provider resolvers may be supplied by
a future engine; no network fetch or provider scraping happens in this module.
"""

from urllib.parse import urlsplit

SUPPORTED_SCHEMES = {"http", "https"}
QUALITY_POINTS = {2160: 55, 1440: 48, 1080: 42, 720: 26, 480: 14, 360: 7}
TYPE_POINTS = {"local": 60, "direct": 36, "cloud": 31, "hoster": 22,
               "embed": 16, "torrent": 10}


def quality_height(value):
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        height = value
    elif isinstance(value, str):
        label = value.strip().lower()
        if label in ("4k", "uhd"):
            return 2160
        digits = "".join(char for char in label if char.isdigit())
        height = int(digits) if digits else 0
    else:
        return 0
    return min(2160, max(0, height))


def source_score(source, preferred_language="sub"):
    """Higher score is better. Unplayable/DRM entries are excluded."""
    if not isinstance(source, dict):
        return None
    if source.get("drm") or source.get("playable") is False:
        return None
    kind = str(source.get("type", "")).lower()
    if kind not in TYPE_POINTS:
        return None

    height = quality_height(source.get("quality", 0))
    points = TYPE_POINTS[kind]
    points += QUALITY_POINTS.get(height, 0)
    if height and height not in QUALITY_POINTS:
        points += min(42, height // 25)
    if source.get("cached") is True:
        points += 48
    if kind == "torrent" and not source.get("cached"):
        points -= 65

    preference = preferred_language.strip().lower()
    language = str(source.get("language", "")).lower()
    if preference and (language == preference or language == "dual"):
        points += 18
    reliability = source.get("reliability", 0)
    if isinstance(reliability, (int, float)) and not isinstance(reliability, bool):
        points += max(0, min(20, reliability * 0.2))
    if kind == "torrent":
        seeders = source.get("seeders", 0)
        if isinstance(seeders, int) and seeders > 0:
            points += min(10, seeders // 5)
    return points


def ranked_sources(sources, preferred_language="sub"):
    """Return compatible candidates in highest-first order; ties stay stable."""
    if not isinstance(sources, list):
        raise ValueError("sources must be a list")
    if len(sources) > 100:
        raise ValueError("maximum 100 source candidates")
    valid = ((source_score(s, preferred_language), i, s)
             for i, s in enumerate(sources))
    valid = ((score, i, source) for score, i, source in valid
             if score is not None)
    return [source for _, _, source in sorted(
        valid, key=lambda row: (-row[0], row[1]))]


def is_http_media_url(url):
    if not isinstance(url, str) or len(url) > 4096:
        return False
    try:
        uri = urlsplit(url)
        return (uri.scheme in SUPPORTED_SCHEMES and bool(uri.hostname)
                and not uri.username and not uri.password)
    except ValueError:
        return False


def select_best(sources, preferred_language="sub", resolver=None):
    """Find the first resolvable HTTP URL, falling back in rank order.

    A future provider engine can pass resolver(source) -> URL or None.
    Without a resolver, entries must already contain direct HTTP media URLs.
    This checks URL syntax, not whether a remote server is currently online.
    """
    for candidate in ranked_sources(sources, preferred_language):
        url = resolver(candidate) if resolver else candidate.get("url")
        if is_http_media_url(url):
            return {"source": candidate, "url": url}
    return None
