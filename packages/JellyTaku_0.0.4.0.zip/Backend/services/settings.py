"""Validated persisted backend settings. Never stores OAuth secrets here."""

import sqlite3

DEFAULTS = {
    "preferred_language": "sub",
    "minimum_resolution": 720,
    "best_source_auto_play": True,
    "retention_days": 30,
}

VALID_LANGUAGES = {"sub", "dub", "dual", "any"}
VALID_RESOLUTIONS = {0, 360, 480, 720, 1080, 2160}


class SettingsStore:
    def __init__(self, filename):
        self.filename = str(filename)
        with sqlite3.connect(self.filename) as db:
            db.execute("CREATE TABLE IF NOT EXISTS backend_settings "
                       "(key TEXT PRIMARY KEY, value TEXT NOT NULL)")

    def get(self):
        from json import loads
        result = dict(DEFAULTS)
        with sqlite3.connect(self.filename) as db:
            for key, raw in db.execute("SELECT key, value FROM backend_settings"):
                if key in DEFAULTS:
                    result[key] = loads(raw)
        return result

    def update(self, payload):
        from json import dumps
        if not isinstance(payload, dict) or not payload:
            raise ValueError("settings update must be a nonempty object")
        unknown = set(payload).difference(DEFAULTS)
        if unknown:
            raise ValueError("unknown settings: " + ", ".join(sorted(unknown)))
        current = self.get()
        updated = dict(current)
        updated.update(payload)
        if updated["preferred_language"] not in VALID_LANGUAGES:
            raise ValueError("invalid preferred_language")
        if type(updated["minimum_resolution"]) is not int or updated["minimum_resolution"] not in VALID_RESOLUTIONS:
            raise ValueError("invalid minimum_resolution")
        if type(updated["best_source_auto_play"]) is not bool:
            raise ValueError("best_source_auto_play must be boolean")
        # Fixed policy for the initial release. Expose now so the admin UI can
        # display it, but don't allow accidental shortening / prolonging.
        if type(updated["retention_days"]) is not int or updated["retention_days"] != 30:
            raise ValueError("retention_days is fixed to 30")
        with sqlite3.connect(self.filename) as db:
            for key, value in payload.items():
                db.execute(
                    "INSERT INTO backend_settings(key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, dumps(value)),
                )
        return updated
