"""Return source-ranking engine status (provider adapters not installed)."""

from selection import select_best  # existing deterministic ranking algorithm


def provider_status():
    return {"status": "no_providers", "providers": [],
            "auto_play": True, "source_selection": "best"}
