"""External watchlist OAuth providers need explicit registered clients.

No authorization redirects or callback endpoints are provided until client
credentials, HTTPS redirect URIs and secret storage are implemented.
"""

PROVIDERS = ("anilist", "myanimelist", "simkl", "kitsu")


def provider_status():
    return [{"provider": provider, "connected": False, "status": "not_configured"}
            for provider in PROVIDERS]
