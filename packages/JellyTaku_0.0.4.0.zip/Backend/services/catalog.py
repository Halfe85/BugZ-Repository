"""Explicit capability registry, avoiding claims that placeholders are operational."""

SERVICES = (
    ("watchlists", "ready", "Per-user local watchlist storage and management"),
    ("scraping", "partial", "Best-source ranking exists; provider adapters not connected"),
    ("metadata", "planned", "Metadata provider connectors not connected"),
    ("oauth", "planned", "Account linking and OAuth callbacks not connected"),
    ("settings", "ready", "Server settings persisted in SQLite"),
    ("streaming_hls", "planned", "Authenticated HLS handling and transcoding are not connected"),
    ("streaming_frontend", "planned", "Client playback endpoint and Jellyfin session mapping not connected"),
    ("jellyfin_library", "planned", "Jellyfin library management belongs to the C# plugin"),
)


def capabilities():
    return [{"id": key, "status": status, "description": description}
            for key, status, description in SERVICES]
