"""Streaming interfaces. Deliberately no arbitrary URL-to-HLS proxy.

Production proxy endpoints must validate provider allowlists, prevent SSRF,
forward Range headers safely, protect access with short-lived tokens, handle
seek/disconnect, and negotiate HLS vs Jellyfin's own transcoding. A placeholder
must not be confused with a playable stream.
"""


def capabilities():
    return {
        "jellyfin_server": {"status": "planned", "formats": ["hls"], "available": False},
        "jellyfin_frontend": {"status": "planned", "formats": ["hls"], "available": False},
        "reason": "No authorized provider and HLS adapter configured",
    }
