"""JellyTaku-managed local watchlists; no external account synchronization yet."""

import sqlite3
import time

STATES = {"planning", "watching", "completed", "paused", "dropped"}


class WatchlistStore:
    def __init__(self, filename):
        self.filename = str(filename)
        with sqlite3.connect(self.filename) as db:
            db.execute(
                """CREATE TABLE IF NOT EXISTS watchlist (
                   user_id TEXT NOT NULL,
                   anime_id TEXT NOT NULL,
                   title TEXT NOT NULL,
                   state TEXT NOT NULL,
                   updated_at REAL NOT NULL,
                   PRIMARY KEY (user_id, anime_id))"""
            )

    def list(self, user_id):
        self._validate_user(user_id)
        with sqlite3.connect(self.filename) as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute(
                "SELECT anime_id, title, state, updated_at FROM watchlist "
                "WHERE user_id=? ORDER BY updated_at DESC LIMIT 500", (user_id,)
            )]

    def upsert(self, user_id, anime_id, title, state):
        self._validate_user(user_id)
        if not isinstance(anime_id, str) or not (1 <= len(anime_id) <= 128):
            raise ValueError("anime_id must contain 1-128 characters")
        if not isinstance(title, str) or not (1 <= len(title.strip()) <= 300):
            raise ValueError("title must contain 1-300 characters")
        if state not in STATES:
            raise ValueError("invalid watchlist state")
        timestamp = time.time()
        with sqlite3.connect(self.filename) as db:
            db.execute(
                "INSERT INTO watchlist VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(user_id, anime_id) DO UPDATE SET "
                "title=excluded.title, state=excluded.state, updated_at=excluded.updated_at",
                (user_id, anime_id, title.strip(), state, timestamp)
            )
        return {"anime_id": anime_id, "title": title.strip(),
                "state": state, "updated_at": timestamp}

    @staticmethod
    def _validate_user(user_id):
        if not isinstance(user_id, str) or not (1 <= len(user_id) <= 128):
            raise ValueError("invalid Jellyfin user_id")
