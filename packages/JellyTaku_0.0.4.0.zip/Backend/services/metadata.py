"""Pluggable metadata adapter registry; actual providers will be added later."""


def provider_status():
    return [{"provider": name, "status": "not_configured"}
            for name in ("anilist", "tmdb", "anidb")]
