"""JellyTaku-only retention of playback entries.

Records expire 30 days after the most recent playback start. This database
contains no media files, signed stream URLs, credentials, or Jellyfin watch data.
"""

import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

RETENTION_DAYS = 30
RETENTION_SECONDS = RETENTION_DAYS * 24 * 60 * 60


def utc_timestamp(value):
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()


class RetentionStore:
    def __init__(self, filename):
        self.filename = Path(filename)
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS recently_streamed (
                item_id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                last_streamed REAL NOT NULL,
                expires_at REAL NOT NULL
                )"""
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_retained_expiry "
                "ON recently_streamed (expires_at)"
            )

    def _connect(self):
        connection = sqlite3.connect(str(self.filename), timeout=5)
        connection.execute("PRAGMA busy_timeout=5000")
        return connection

    def prune(self, now=None):
        now = time.time() if now is None else now
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM recently_streamed WHERE expires_at <= ?", (now,)
            )
            return cursor.rowcount

    def mark_streamed(self, item_id, title, now=None):
        if not isinstance(item_id, str) or not item_id.startswith("jellytaku:") or len(item_id) > 256:
            raise ValueError("item_id must identify a JellyTaku channel item")
        if not isinstance(title, str) or not title.strip() or len(title) > 512:
            raise ValueError("invalid item title")
        now = time.time() if now is None else now
        expires_at = now + RETENTION_SECONDS
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO recently_streamed
                (item_id, title, last_streamed, expires_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(item_id) DO UPDATE SET
                  title=excluded.title,
                  last_streamed=excluded.last_streamed,
                  expires_at=excluded.expires_at""",
                (item_id, title.strip(), now, expires_at),
            )
        return {"item_id": item_id, "title": title.strip(),
                "last_streamed": utc_timestamp(now),
                "expires_at": utc_timestamp(expires_at)}

    def recent(self, now=None, limit=100):
        now = time.time() if now is None else now
        limit = max(1, min(100, int(limit)))
        self.prune(now)
        with self._connect() as connection:
            rows = connection.execute(
                """SELECT item_id, title, last_streamed, expires_at
                FROM recently_streamed WHERE expires_at > ?
                ORDER BY last_streamed DESC LIMIT ?""", (now, limit),
            ).fetchall()
        return [{"item_id": item_id, "title": title,
                 "last_streamed": utc_timestamp(last),
                 "expires_at": utc_timestamp(expiry)}
                for item_id, title, last, expiry in rows]
