"""Family groups, trusted invitations and parent-controlled child permissions.

All membership checks are server-side and use immutable JellyTaku account IDs.
One family per member prevents competing guardians and locked-in invitations.
An invitation is not membership until the invitee explicitly accepts.
Children under 15 are shown that accepting means they cannot independently
leave until 15; trusted family adults may remove or transfer their membership.
"""
from datetime import datetime, timezone
import sqlite3
import time
import uuid

from services.accounts import AccountError


class FamilyError(AccountError):
    pass


class Families:
    def __init__(self, accounts):
        self.accounts = accounts
        with accounts.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS families (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    creator_id TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS family_members (
                    family_id TEXT NOT NULL,
                    account_id TEXT NOT NULL UNIQUE,
                    joined_at REAL NOT NULL,
                    PRIMARY KEY (family_id, account_id)
                );
                CREATE TABLE IF NOT EXISTS family_invites (
                    id TEXT PRIMARY KEY,
                    family_id TEXT NOT NULL,
                    inviter_id TEXT NOT NULL,
                    invitee_id TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending'
                        CHECK(status IN ('pending','accepted','declined','cancelled')),
                    created_at REAL NOT NULL,
                    responded_at REAL
                );
            """)

    def _profile(self, uid):
        if not isinstance(uid, str):
            raise FamilyError("A JellyTaku user account is required")
        return self.accounts.get(uid)

    @staticmethod
    def _adult(profile):
        return profile["age"] is not None and profile["age"] >= 18

    @staticmethod
    def _leave_allowed(profile):
        return profile["age"] is not None and profile["age"] >= 15

    def _membership(self, db, uid):
        return db.execute(
            "SELECT family_id FROM family_members WHERE account_id=?", (uid,)
        ).fetchone()

    def _require_group_member(self, db, family_id, uid, admin=False):
        family = db.execute("SELECT * FROM families WHERE id=?", (family_id,)).fetchone()
        if family is None:
            raise FamilyError("Family group not found")
        if not admin and not db.execute(
                "SELECT 1 FROM family_members WHERE family_id=? AND account_id=?",
                (family_id, uid)).fetchone():
            raise FamilyError("Not a member of this family")
        return family

    def _ensure_child_has_guardian(self, db, family_id, departing_id):
        remaining = [row["account_id"] for row in db.execute(
            "SELECT account_id FROM family_members WHERE family_id=? AND account_id<>?",
            (family_id, departing_id))]
        if remaining and any(
                self._profile(uid)["age"] is None or
                self._profile(uid)["age"] < 18 for uid in remaining):
            if not any(self._adult(self._profile(uid)) for uid in remaining):
                raise FamilyError("A family with minors must retain an adult guardian")

    def create(self, actor_id, name, admin=False, owner_username=None):
        # The original bootstrap admin has no end-user profile, so they
        # create a family on behalf of an existing adult JellyTaku account.
        if admin and owner_username:
            with self.accounts.db() as lookup:
                owner = lookup.execute(
                    "SELECT id FROM accounts WHERE username=? COLLATE NOCASE",
                    (owner_username,)).fetchone()
            if not owner:
                raise FamilyError("Family owner must be an existing JellyTaku user")
            actor_id = owner["id"]
        actor = self._profile(actor_id)
        if not self._adult(actor):
            raise FamilyError("Only an adult (18+) can start a family group")
        if not isinstance(name, str) or not 2 <= len(name.strip()) <= 80:
            raise FamilyError("Family name must be 2-80 characters")
        family_id = str(uuid.uuid4())
        with self.accounts.lock, self.accounts.db() as db:
            if self._membership(db, actor_id):
                raise FamilyError("Account already belongs to a family")
            db.execute(
                "INSERT INTO families VALUES (?, ?, ?, ?)",
                (family_id, name.strip(), actor_id, time.time()))
            db.execute(
                "INSERT INTO family_members VALUES (?, ?, ?)",
                (family_id, actor_id, time.time()))
            db.commit()
        return self.details(family_id, actor_id, admin)

    def details(self, family_id, actor_id, admin=False):
        with self.accounts.lock, self.accounts.db() as db:
            family = self._require_group_member(db, family_id, actor_id, admin)
            is_adult = admin or (actor_id is not None and
                                 self._adult(self._profile(actor_id)))
            members = []
            for row in db.execute(
                    "SELECT account_id FROM family_members WHERE family_id=? "
                    "ORDER BY joined_at", (family_id,)):
                profile = self._profile(row["account_id"])
                member = {
                    "id": profile["id"], "username": profile["username"],
                    "name": profile["name"], "age": profile["age"],
                    "age_group": profile["age_group"],
                    "role": profile["role"],
                    "can_leave": profile["can_leave_family"],
                    "is_adult": self._adult(profile)
                }
                if is_adult and profile["age"] is not None and profile["age"] < 18:
                    member["selected_permissions"] = profile["selected_permissions"]
                    member["email"] = profile["email"]
                    member["status"] = profile["status"]
                members.append(member)
            return {"id": family["id"], "name": family["name"],
                    "creator_id": family["creator_id"], "members": members,
                    "can_manage_children": is_adult}

    def my_groups(self, actor_id, admin=False):
        with self.accounts.lock, self.accounts.db() as db:
            if admin:
                families = [row["id"] for row in db.execute(
                    "SELECT id FROM families ORDER BY name")]
            else:
                families = [row["family_id"] for row in db.execute(
                    "SELECT family_id FROM family_members WHERE account_id=?",
                    (actor_id,))]
        return [self.details(uid, actor_id, admin) for uid in families]

    def invite(self, family_id, actor_id, username, admin=False):
        if not isinstance(username, str):
            raise FamilyError("Invitee username is required")
        with self.accounts.lock, self.accounts.db() as db:
            self._require_group_member(db, family_id, actor_id, admin)
            target = db.execute(
                "SELECT id FROM accounts WHERE username=? COLLATE NOCASE",
                (username.strip(),)).fetchone()
            if not target:
                raise FamilyError("JellyTaku account not found")
            uid = target["id"]
            # Adults gain guardian powers over all minors in this family.
            # A child may invite other children, but may not grant an adult
            # guardian privileges by inviting them into the household.
            if not admin and self._adult(self._profile(uid)) and not self._adult(
                    self._profile(actor_id)):
                raise FamilyError("Only existing adult members can invite another adult guardian")
            if self._membership(db, uid):
                raise FamilyError("This user already belongs to a family")
            if db.execute(
                    "SELECT 1 FROM family_invites WHERE family_id=? "
                    "AND invitee_id=? AND status='pending'",
                    (family_id, uid)).fetchone():
                raise FamilyError("An invitation is already pending")
            inv_id = str(uuid.uuid4())
            db.execute(
                "INSERT INTO family_invites VALUES (?, ?, ?, ?, 'pending', ?, NULL)",
                (inv_id, family_id, actor_id, uid, time.time()))
            db.commit()
        return {"id": inv_id, "family_id": family_id, "invitee_id": uid,
                "status": "pending"}

    def inbox(self, actor_id, admin=False):
        with self.accounts.lock, self.accounts.db() as db:
            if admin:
                rows = db.execute("""
                    SELECT i.*, f.name AS family_name, a.username AS invitee_name
                    FROM family_invites i JOIN families f ON f.id=i.family_id
                    JOIN accounts a ON a.id=i.invitee_id
                    WHERE i.status='pending' ORDER BY i.created_at
                """)
            else:
                rows = db.execute("""
                    SELECT i.*, f.name AS family_name, a.username AS invitee_name
                    FROM family_invites i JOIN families f ON f.id=i.family_id
                    JOIN accounts a ON a.id=i.invitee_id
                    WHERE i.invitee_id=? AND i.status='pending'
                    ORDER BY i.created_at
                """, (actor_id,))
            return [{
                "id": row["id"], "family_id": row["family_id"],
                "family_name": row["family_name"], "invitee_id": row["invitee_id"],
                "invitee_name": row["invitee_name"],
                "under_15": (
                    self._profile(row["invitee_id"])["age"] is None or
                    self._profile(row["invitee_id"])["age"] < 15)
            } for row in rows]

    def respond(self, invitation_id, actor_id, action, admin=False):
        if action not in ("accept", "decline"):
            raise FamilyError("Invalid invitation action")
        with self.accounts.lock, self.accounts.db() as db:
            invite = db.execute(
                "SELECT * FROM family_invites WHERE id=?", (invitation_id,)
            ).fetchone()
            if invite is None or invite["status"] != "pending":
                raise FamilyError("Invitation is not pending")
            profile = self._profile(invite["invitee_id"])
            if not admin and actor_id != invite["invitee_id"]:
                raise FamilyError("Only the invited user can respond")
            if action == "accept":
                if self._membership(db, invite["invitee_id"]):
                    raise FamilyError("Account already belongs to a family")
                # The family must still have a guardian before a minor joins.
                if not any(self._adult(self._profile(row["account_id"])) for row
                           in db.execute(
                               "SELECT account_id FROM family_members WHERE family_id=?",
                               (invite["family_id"],))):
                    raise FamilyError("Family needs an adult guardian")
                try:
                    db.execute(
                        "INSERT INTO family_members VALUES (?, ?, ?)",
                        (invite["family_id"], invite["invitee_id"], time.time()))
                except sqlite3.IntegrityError as exc:
                    raise FamilyError("Account already belongs to a family") from exc
            db.execute(
                "UPDATE family_invites SET status=?, responded_at=? WHERE id=?",
                ("accepted" if action == "accept" else "declined",
                 time.time(), invitation_id))
            db.execute(
                "UPDATE family_invites SET status='cancelled', responded_at=? "
                "WHERE invitee_id=? AND id<>? AND status='pending'",
                (time.time(), invite["invitee_id"], invitation_id)
            ) if action == "accept" else None
            db.commit()
            return {"id": invitation_id, "status": action}

    def leave(self, family_id, actor_id, admin=False):
        if admin and actor_id is None:
            raise FamilyError("A system administrator does not have a family membership")
        profile = self._profile(actor_id)
        if not self._leave_allowed(profile):
            raise FamilyError("Children under 15 cannot leave their family group")
        with self.accounts.lock, self.accounts.db() as db:
            self._require_group_member(db, family_id, actor_id)
            self._ensure_child_has_guardian(db, family_id, actor_id)
            db.execute(
                "DELETE FROM family_members WHERE family_id=? AND account_id=?",
                (family_id, actor_id))
            if not db.execute(
                    "SELECT 1 FROM family_members WHERE family_id=?",
                    (family_id,)).fetchone():
                db.execute("DELETE FROM family_invites WHERE family_id=?", (family_id,))
                db.execute("DELETE FROM families WHERE id=?", (family_id,))
            db.commit()
        return {"left": True}

    def remove_member_as_admin(self, family_id, member_id, admin=False):
        if not admin:
            raise FamilyError("Only JellyTaku administrators may remove any member")
        with self.accounts.lock, self.accounts.db() as db:
            self._require_group_member(db, family_id, None, True)
            if not db.execute(
                    "SELECT 1 FROM family_members WHERE family_id=? AND account_id=?",
                    (family_id, member_id)).fetchone():
                raise FamilyError("Member is not in this family")
            self._ensure_child_has_guardian(db, family_id, member_id)
            db.execute(
                "DELETE FROM family_members WHERE family_id=? AND account_id=?",
                (family_id, member_id))
            if not db.execute(
                    "SELECT 1 FROM family_members WHERE family_id=?",
                    (family_id,)).fetchone():
                db.execute("DELETE FROM family_invites WHERE family_id=?", (family_id,))
                db.execute("DELETE FROM families WHERE id=?", (family_id,))
            db.commit()
        return {"removed": True}

    def remove_child(self, family_id, actor_id, child_id, admin=False):
        child = self._profile(child_id)
        if child["age"] is None or child["age"] >= 18:
            raise FamilyError("Only minors may be removed by a family guardian")
        with self.accounts.lock, self.accounts.db() as db:
            self._require_group_member(db, family_id, actor_id, admin)
            if not admin and not self._adult(self._profile(actor_id)):
                raise FamilyError("Only adult guardians can manage children")
            if not db.execute(
                    "SELECT 1 FROM family_members WHERE family_id=? AND account_id=?",
                    (family_id, child_id)).fetchone():
                raise FamilyError("Child is not in this family")
            db.execute(
                "DELETE FROM family_members WHERE family_id=? AND account_id=?",
                (family_id, child_id))
            db.commit()
        return {"removed": True}

    def _guardian_for(self, db, family_id, actor_id, child_id, admin=False):
        child = self._profile(child_id)
        if child["age"] is None or child["age"] >= 18 or child["role"] != "user":
            raise FamilyError("Family guardians may manage regular users under 18")
        self._require_group_member(db, family_id, actor_id, admin)
        if not admin and not self._adult(self._profile(actor_id)):
            raise FamilyError("Only adult guardians can manage children")
        if not db.execute(
                "SELECT 1 FROM family_members WHERE family_id=? AND account_id=?",
                (family_id, child_id)).fetchone():
            raise FamilyError("Child is not in this family")

    def manage_child(self, family_id, actor_id, child_id, changes, admin=False):
        if isinstance(changes, list):
            changes = {"permissions": changes}
        with self.accounts.lock, self.accounts.db() as db:
            self._guardian_for(db, family_id, actor_id, child_id, admin)
            return self.accounts.update_child_profile(child_id, changes)

    def reset_child_password(self, family_id, actor_id, child_id, admin=False):
        with self.accounts.lock, self.accounts.db() as db:
            self._guardian_for(db, family_id, actor_id, child_id, admin)
            return self.accounts.generate_password(child_id)
