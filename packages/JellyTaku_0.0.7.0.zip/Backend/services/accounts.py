"""JellyTaku-owned end-user directory. Jellyfin is a downstream projection.

No automatic import or overwrite from Jellyfin. Administrator authentication
remains in auth.sqlite3 while end-user management is being developed.
"""
import hashlib
from datetime import date, datetime, timezone
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
import uuid

ITERATIONS = 310_000
USERNAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,62}$")
EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}$")


class AccountError(ValueError):
    pass



# Authorization is evaluated by Python on every request. Age guidance is
# optional parent/admin context and NEVER used as an automatic age gate.
ROLES = ("admin", "moderator", "user")
USER_CAPABILITIES = (
    "discovery.view", "requests.create", "watchlist.view",
    "watchlist.edit", "playback.start"
)
MODERATOR_CAPABILITIES = USER_CAPABILITIES + (
    "moderation.requests", "moderation.watchlists"
)
ADMIN_CAPABILITIES = MODERATOR_CAPABILITIES + (
    "users.view", "users.manage", "settings.manage", "retained.view"
)
SESSION_TTL = 8 * 3600
MAX_FAILURES = 5
LOCK_SECONDS = 15 * 60



def parse_birth_date(value):
    if not isinstance(value, str) or len(value) != 10:
        raise AccountError("Date of birth must be in YYYY-MM-DD format")
    try:
        dob = date.fromisoformat(value)
    except ValueError as exc:
        raise AccountError("Invalid date of birth") from exc
    today = datetime.now(timezone.utc).date()
    if dob > today or dob.year < today.year - 120:
        raise AccountError("Date of birth must be a plausible past date")
    return dob


def age_from_dob(value, on_date=None):
    if value is None:
        return None
    born = parse_birth_date(value)
    today = on_date or datetime.now(timezone.utc).date()
    return today.year - born.year - (
        (today.month, today.day) < (born.month, born.day)
    )


def age_group(age):
    if age is None:
        return "unset"
    if age < 15:
        return "child"
    if age < 18:
        return "teen"
    return "adult"


def effective_permissions(role, selected):
    if role == "admin":
        return list(ADMIN_CAPABILITIES)
    if role == "moderator":
        return list(MODERATOR_CAPABILITIES)
    # Users only get permissions explicitly selected by the family admin.
    return [value for value in USER_CAPABILITIES if value in selected]


def validate_access(role, permissions):
    if role not in ROLES:
        raise AccountError("Role must be admin, moderator or user")
    if not isinstance(permissions, list) or any(
            not isinstance(x, str) or x not in USER_CAPABILITIES for x in permissions):
        raise AccountError("Invalid selectable user permissions")
    if len(set(permissions)) != len(permissions):
        raise AccountError("Duplicate user permissions")
    return role, list(permissions)

class ManagedAccounts:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(self.path), os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        os.chmod(self.path, 0o600)
        self.lock = threading.RLock()
        # Secrets are RAM-only. Interrupted sync requires regeneration.
        self.pending_passwords = {}
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS accounts (
                    id TEXT PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    status TEXT NOT NULL CHECK(status IN ('active','disabled')),
                    role TEXT NOT NULL CHECK(role IN ('user')),
                    password_hash BLOB,
                    salt BLOB,
                    iterations INTEGER,
                    jellyfin_id TEXT UNIQUE,
                    revision INTEGER NOT NULL DEFAULT 1,
                    synced_revision INTEGER NOT NULL DEFAULT 0,
                    password_synced INTEGER NOT NULL DEFAULT 0,
                    last_sync_error TEXT,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS account_access (
                    account_id TEXT PRIMARY KEY REFERENCES accounts(id),
                    role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'moderator', 'user')),
                    permissions_json TEXT NOT NULL DEFAULT '[]',
                    age_guidance TEXT NOT NULL DEFAULT 'unspecified',
                    date_of_birth TEXT,
                    failed_logins INTEGER NOT NULL DEFAULT 0,
                    locked_until REAL NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS account_sessions (
                    token_hash TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL REFERENCES accounts(id),
                    expires_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS account_sessions_expiry
                    ON account_sessions(expires_at);
            """)
            # The draft migration remains non-destructive. Legacy records
            # without a birth date cannot acquire adult/guardian privileges
            # until an administrator supplies their real birth date.
            existing = {col["name"] for col in db.execute(
                "PRAGMA table_info(account_access)")}
            if "date_of_birth" not in existing:
                db.execute("ALTER TABLE account_access ADD COLUMN date_of_birth TEXT")
            # Preserve accounts created by earlier drafts. They were regular
            # users, so grant only the minimal discovery permission.
            db.execute("""
                INSERT OR IGNORE INTO account_access (
                    account_id, role, permissions_json, age_guidance)
                SELECT id, 'user', '["discovery.view"]', 'unspecified'
                FROM accounts
            """)

    def db(self):
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    @staticmethod
    def validate(username, name, email, status):
        if not isinstance(username, str) or not USERNAME.fullmatch(username):
            raise AccountError("Username must be 2-63 letters, numbers, dots, dashes or underscores")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 100:
            raise AccountError("Display name must have 1-100 characters")
        if not isinstance(email, str) or not EMAIL.fullmatch(email) or len(email) > 254:
            raise AccountError("A valid email address is required")
        if status not in ("active", "disabled"):
            raise AccountError("Invalid account status")
        return username.strip(), name.strip(), email.strip().lower(), status

    def public(self, row):
        with self.db() as db:
            access = db.execute(
                "SELECT * FROM account_access WHERE account_id=?", (row["id"],)
            ).fetchone()
        role = access["role"] if access else "user"
        selected = json.loads(access["permissions_json"]) if access else []
        dob = access["date_of_birth"] if access else None
        age = age_from_dob(dob) if dob else None
        secret = self.pending_passwords.get(row["id"])
        if row["jellyfin_id"] and row["synced_revision"] >= row["revision"]:
            sync = "synced"
        elif (not row["jellyfin_id"] or not row["password_synced"]) and not secret:
            sync = "password_required"
        elif row["last_sync_error"]:
            sync = "error"
        else:
            sync = "pending"
        return {
            "id": row["id"], "username": row["username"], "name": row["name"],
            "email": row["email"], "status": row["status"], "role": role,
            "permissions": effective_permissions(role, selected),
            "selected_permissions": selected,
            "date_of_birth": dob, "age": age, "age_group": age_group(age),
            "age_settings": {
                "profile": age_group(age),
                "parent_managed": age is None or age < 18,
                "guardian_privileges": age is not None and age >= 18,
                "independent_family_exit": age is not None and age >= 15,
                "join_needs_admin_approval": age is None or age < 15
            },
            "can_leave_family": age is not None and age >= 15,
            "can_manage_children": age is not None and age >= 18,
            "jellyfin_id": row["jellyfin_id"],
            "sync_status": sync, "sync_error": row["last_sync_error"]
        }

    def list(self):
        with self.lock, self.db() as db:
            return [self.public(row) for row in db.execute(
                "SELECT * FROM accounts ORDER BY username COLLATE NOCASE")]

    def get(self, uid):
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (uid,)).fetchone()
            if row is None:
                raise AccountError("Unknown JellyTaku account")
            return self.public(row)

    def create(self, username, name, email, role="user",
               permissions=None, date_of_birth=None):
        username, name, email, _ = self.validate(username, name, email, "active")
        dob = parse_birth_date(date_of_birth).isoformat()
        role, permissions = validate_access(
            role, ["discovery.view"] if permissions is None else permissions)
        if username.lower() == "admin":
            raise AccountError("Reserved administrator username")
        uid = str(uuid.uuid4())
        now = time.time()
        with self.lock, self.db() as db:
            try:
                db.execute("""
                    INSERT INTO accounts (id, username, name, email, status,
                        role, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 'active', 'user', ?, ?)
                """, (uid, username, name, email, now, now))
                db.execute(
                    "INSERT INTO account_access (account_id, role, permissions_json, date_of_birth) "
                    "VALUES (?, ?, ?, ?)",
                    (uid, role, json.dumps(permissions), dob))
            except sqlite3.IntegrityError as exc:
                raise AccountError("Username or email already registered") from exc
        return self.get(uid)

    def update(self, uid, changes):
        if not isinstance(changes, dict) or not changes or not set(changes).issubset(
                {"username", "name", "email", "status", "role",
                 "permissions", "date_of_birth"}):
            raise AccountError("Unsupported account fields")
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (uid,)).fetchone()
            if row is None:
                raise AccountError("Unknown JellyTaku account")
            current = db.execute(
                "SELECT * FROM account_access WHERE account_id=?", (uid,)
            ).fetchone()
            role, selected = validate_access(
                changes.get("role", current["role"]),
                changes.get("permissions", json.loads(current["permissions_json"])))
            # Only the backend administrator route may supply date_of_birth.
            # Regular/family routes have an explicit safe allowlist.
            dob = changes.get("date_of_birth", current["date_of_birth"])
            if dob is not None:
                dob = parse_birth_date(dob).isoformat()
            else:
                raise AccountError("Date of birth is required")
            # An admin correction must not strand a household with minors
            # and no adult guardian. Birthday transitions use the live age
            # calculation; this check covers manual DOB corrections.
            if ("date_of_birth" in changes and dob != current["date_of_birth"]
                    and age_from_dob(dob) < 18 and db.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' "
                        "AND name='family_members'").fetchone()):
                membership = db.execute(
                    "SELECT family_id FROM family_members WHERE account_id=?",
                    (uid,)).fetchone()
                if membership:
                    guardians = db.execute("""
                        SELECT aa.date_of_birth FROM family_members fm
                        JOIN account_access aa ON aa.account_id=fm.account_id
                        WHERE fm.family_id=? AND fm.account_id<>?
                    """, (membership["family_id"], uid)).fetchall()
                    if not any(g["date_of_birth"] and
                               age_from_dob(g["date_of_birth"]) >= 18
                               for g in guardians):
                        raise AccountError(
                            "Set another adult guardian before correcting this family member to a minor")
            username, name, email, status = self.validate(
                changes.get("username", row["username"]),
                changes.get("name", row["name"]),
                changes.get("email", row["email"]),
                changes.get("status", row["status"]))
            if username.lower() == "admin":
                raise AccountError("Reserved administrator username")
            try:
                db.execute("""
                    UPDATE accounts SET username=?, name=?, email=?, status=?,
                        revision=revision+1, last_sync_error=NULL, updated_at=?
                    WHERE id=?
                """, (username, name, email, status, time.time(), uid))
                db.execute("""
                    UPDATE account_access SET role=?, permissions_json=?,
                        date_of_birth=? WHERE account_id=?
                """, (role, json.dumps(selected), dob, uid))
            except sqlite3.IntegrityError as exc:
                raise AccountError("Username or email already registered") from exc
            db.commit()
        return self.get(uid)

    def update_child_profile(self, uid, changes):
        # Family adults never get an administrator's general update powers.
        # Only a regular user's display name, email, status and selected
        # capabilities are editable. DOB, role and username are excluded.
        if not isinstance(changes, dict) or not changes or not set(changes).issubset(
                {"name", "email", "status", "permissions"}):
            raise AccountError("Family guardians cannot change identity, birth date or role")
        profile = self.get(uid)
        if profile["role"] != "user":
            raise AccountError("A family guardian cannot manage a privileged role")
        return self.update(uid, changes)

    def update_child_permissions(self, uid, selected):
        # Guardians may update ONLY grants of a child, never the child's
        # identity, birth date, role or global account status.
        if not isinstance(selected, list):
            raise AccountError("Invalid permissions")
        role, selected = validate_access("user", selected)
        with self.lock, self.db() as db:
            row = db.execute(
                "SELECT role FROM account_access WHERE account_id=?", (uid,)
            ).fetchone()
            if row is None or row["role"] != "user":
                raise AccountError("Family access can only manage regular user grants")
            db.execute(
                "UPDATE account_access SET permissions_json=? WHERE account_id=?",
                (json.dumps(selected), uid))
            db.commit()
        return self.get(uid)

    def generate_password(self, uid):
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%"
        password = "".join(secrets.choice(alphabet) for _ in range(24))
        salt = secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, ITERATIONS)
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (uid,)).fetchone()
            if row is None:
                raise AccountError("Unknown JellyTaku account")
            revision = row["revision"] + 1
            db.execute("""
                UPDATE accounts SET password_hash=?, salt=?, iterations=?,
                    password_synced=0, revision=?, last_sync_error=NULL,
                    updated_at=? WHERE id=?
            """, (digest, salt, ITERATIONS, revision, time.time(), uid))
            db.commit()
            self.pending_passwords[uid] = (revision, password)
        return {"account": self.get(uid), "password": password}


    @staticmethod
    def token_hash(token):
        return hashlib.sha256(token.encode("ascii")).hexdigest()

    def login(self, username, password):
        from services.auth import AuthError
        if not isinstance(username, str) or not isinstance(password, str) or not (
                1 <= len(username) <= 100 and 1 <= len(password) <= 512):
            raise AuthError(401, "Invalid username or password")
        with self.lock, self.db() as db:
            row = db.execute("""
                SELECT accounts.*, account_access.failed_logins,
                    account_access.locked_until FROM accounts
                JOIN account_access ON accounts.id=account_access.account_id
                WHERE accounts.username=? COLLATE NOCASE
            """, (username,)).fetchone()
            if row is None or row["password_hash"] is None:
                hashlib.pbkdf2_hmac(
                    "sha256", password.encode("utf-8"), bytes(16), ITERATIONS)
                raise AuthError(401, "Invalid username or password")
            now = time.time()
            if row["locked_until"] > now:
                raise AuthError(429, "Too many attempts. Try again later.")
            digest = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"),
                row["salt"], row["iterations"])
            if not hmac.compare_digest(digest, row["password_hash"]):
                failures = row["failed_logins"] + 1
                lock = now + LOCK_SECONDS if failures >= MAX_FAILURES else 0
                db.execute("""
                    UPDATE account_access SET failed_logins=?, locked_until=?
                    WHERE account_id=?
                """, (failures, lock, row["id"]))
                db.commit()
                raise AuthError(429 if lock else 401,
                    "Too many attempts. Try again later." if lock else
                    "Invalid username or password")
            if row["status"] != "active":
                raise AuthError(403, "This account is disabled")
            db.execute("""
                UPDATE account_access SET failed_logins=0, locked_until=0
                WHERE account_id=?
            """, (row["id"],))
            db.execute("DELETE FROM account_sessions WHERE expires_at<=?", (now,))
            token = secrets.token_urlsafe(48)
            db.execute("""
                INSERT INTO account_sessions (token_hash, account_id, expires_at)
                VALUES (?, ?, ?)
            """, (self.token_hash(token), row["id"], now + SESSION_TTL))
        return {"access_token": token, "expires_in": SESSION_TTL,
                "user": self.get(row["id"])}

    def current_user(self, token):
        if not isinstance(token, str) or not 32 <= len(token) <= 256:
            return None
        try:
            digest = self.token_hash(token)
        except UnicodeEncodeError:
            return None
        with self.lock, self.db() as db:
            row = db.execute("""
                SELECT accounts.* FROM account_sessions
                JOIN accounts ON accounts.id=account_sessions.account_id
                WHERE account_sessions.token_hash=?
                    AND account_sessions.expires_at>?
                    AND accounts.status='active'
            """, (digest, time.time())).fetchone()
            return self.public(row) if row is not None else None

    def logout(self, token):
        if not isinstance(token, str) or not 32 <= len(token) <= 256:
            return
        try:
            digest = self.token_hash(token)
        except UnicodeEncodeError:
            return
        with self.lock, self.db() as db:
            db.execute(
                "DELETE FROM account_sessions WHERE token_hash=?", (digest,))

    def change_password(self, token, current_password, new_password):
        from services.auth import AuthError
        user = self.current_user(token)
        if user is None:
            raise AuthError(401, "Session expired. Sign in again.")
        if not isinstance(current_password, str) or not isinstance(
                new_password, str) or not 12 <= len(new_password) <= 512:
            raise AuthError(400, "New password must have at least 12 characters")
        if current_password == new_password:
            raise AuthError(400, "Choose a different password")
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (user["id"],)).fetchone()
            old_digest = hashlib.pbkdf2_hmac(
                "sha256", current_password.encode("utf-8"),
                row["salt"], row["iterations"])
            if not hmac.compare_digest(old_digest, row["password_hash"]):
                raise AuthError(403, "Current password is incorrect")
            salt = secrets.token_bytes(16)
            digest = hashlib.pbkdf2_hmac(
                "sha256", new_password.encode("utf-8"), salt, ITERATIONS)
            revision = row["revision"] + 1
            db.execute("""
                UPDATE accounts SET password_hash=?, salt=?, iterations=?,
                    password_synced=0, revision=?, last_sync_error=NULL,
                    updated_at=? WHERE id=?
            """, (digest, salt, ITERATIONS, revision, time.time(), user["id"]))
            db.execute("DELETE FROM account_sessions WHERE account_id=?", (user["id"],))
            db.commit()
            self.pending_passwords[user["id"]] = (revision, new_password)
        return {"changed": True, "login_required": True}

    def desired(self):
        """Only available to the localhost, token-authenticated C# adapter."""
        with self.lock, self.db() as db:
            results = []
            for row in db.execute("SELECT * FROM accounts ORDER BY created_at"):
                queued = self.pending_passwords.get(row["id"])
                if row["synced_revision"] >= row["revision"]:
                    continue
                # Never provision a passwordless user when RAM secret is lost.
                if (not row["jellyfin_id"] or not row["password_synced"]) and not queued:
                    continue
                access = db.execute(
                    "SELECT role FROM account_access WHERE account_id=?",
                    (row["id"],)).fetchone()
                results.append({
                    "id": row["id"], "username": row["username"],
                    "role": access["role"] if access else "user",
                    "status": row["status"], "jellyfin_id": row["jellyfin_id"],
                    "revision": row["revision"],
                    "password": queued[1] if queued and queued[0] == row["revision"] else None
                })
            return results

    def bind(self, uid, revision, jellyfin_id):
        """Record a newly provisioned Jellyfin mapping before setting password.

        This makes password retry safe even when later sync operations fail.
        A mapping can never be silently reassigned to another Jellyfin user.
        """
        try:
            uuid.UUID(uid)
            uuid.UUID(jellyfin_id)
        except (TypeError, ValueError) as exc:
            raise AccountError("Invalid account or Jellyfin id") from exc
        if type(revision) is not int:
            raise AccountError("Invalid revision")
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (uid,)).fetchone()
            if row is None or row["revision"] != revision:
                raise AccountError("Unknown or stale sync revision")
            if row["jellyfin_id"] and row["jellyfin_id"] != jellyfin_id:
                raise AccountError("Jellyfin mapping cannot be changed")
            db.execute("UPDATE accounts SET jellyfin_id=? WHERE id=?",
                       (jellyfin_id, uid))
            db.commit()
        return self.get(uid)

    def acknowledge(self, uid, revision, jellyfin_id, error=None):
        try:
            uuid.UUID(uid)
            if jellyfin_id is not None:
                uuid.UUID(jellyfin_id)
        except (TypeError, ValueError) as exc:
            raise AccountError("Invalid account or Jellyfin id") from exc
        if type(revision) is not int:
            raise AccountError("Invalid revision")
        if not error and not jellyfin_id:
            raise AccountError("Successful sync requires a Jellyfin id")
        with self.lock, self.db() as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (uid,)).fetchone()
            if row is None or row["revision"] != revision:
                raise AccountError("Unknown or stale sync revision")
            if row["jellyfin_id"] and jellyfin_id and row["jellyfin_id"] != jellyfin_id:
                raise AccountError("Jellyfin mapping cannot be changed")
            if error:
                db.execute(
                    "UPDATE accounts SET last_sync_error=? WHERE id=?",
                    (str(error)[:400], uid))
            else:
                db.execute("""
                    UPDATE accounts SET jellyfin_id=?, synced_revision=?,
                        password_synced=1, last_sync_error=NULL WHERE id=?
                """, (jellyfin_id, revision, uid))
                self.pending_passwords.pop(uid, None)
            db.commit()
        return self.get(uid)
