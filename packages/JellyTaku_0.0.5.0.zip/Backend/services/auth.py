"""Database-backed JellyTaku admin auth. Never reuse Jellyfin passwords or tokens.

The install-time bootstrap JSON is read ONLY to seed an empty, new database.
The known admin/admin credential may be used solely from loopback and solely
to replace the default password. It cannot access normal management APIs.
"""
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time

ITERATIONS = 310_000
SESSION_TTL = 8 * 3600
MAX_FAILURES = 5
LOCK_SECONDS = 15 * 60


class AuthError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


class AuthStore:
    def __init__(self, database_path, bootstrap_json):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        # Restrict the auth DB to the Jellyfin service account. On an existing
        # DB, restore owner-only mode rather than trusting a lax old umask.
        fd = os.open(str(self.database_path), os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        os.chmod(self.database_path, 0o600)
        with self.db() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash BLOB NOT NULL,
                    salt BLOB NOT NULL,
                    iterations INTEGER NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('admin')),
                    must_change_password INTEGER NOT NULL DEFAULT 0,
                    failed_logins INTEGER NOT NULL DEFAULT 0,
                    locked_until REAL NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    created_at REAL NOT NULL,
                    expires_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
                CREATE TABLE IF NOT EXISTS auth_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
            """)
            # One-time seed; NEVER recreate admin after first initialization
            # even if user rows are subsequently deleted or changed.
            initialized = connection.execute(
                "SELECT value FROM auth_meta WHERE key='initialized'"
            ).fetchone()
            if initialized is None:
                if connection.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
                    bootstrap = json.loads(Path(bootstrap_json).read_text(encoding="utf-8"))
                    username = bootstrap["username"]
                    password = bootstrap["password"]
                    if username != "admin" or password != "admin":
                        raise ValueError("Unexpected bundled bootstrap configuration")
                    salt, hashed = self.hash_password(password)
                    now = time.time()
                    connection.execute(
                        """INSERT INTO users
                        (username, password_hash, salt, iterations, role,
                        must_change_password, created_at, updated_at)
                        VALUES (?, ?, ?, ?, 'admin', 1, ?, ?)""",
                        (username, hashed, salt, ITERATIONS, now, now)
                    )
                connection.execute(
                    "INSERT INTO auth_meta(key, value) VALUES('initialized', '1')"
                )

    def db(self):
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @staticmethod
    def hash_password(password, salt=None):
        salt = salt or secrets.token_bytes(16)
        hashed = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
        return salt, hashed

    @staticmethod
    def valid_password(password, minimum=1):
        return isinstance(password, str) and minimum <= len(password) <= 512

    @staticmethod
    def public_user(row):
        return {
            "id": row["id"],
            "username": row["username"],
            "role": row["role"],
            "must_change_password": bool(row["must_change_password"]),
        }

    def status(self):
        with self.db() as db:
            row = db.execute("SELECT COUNT(*) FROM users WHERE must_change_password=1").fetchone()
            return {"setup_required": row[0] != 0}

    def login(self, username, password, is_loopback):
        if not isinstance(username, str) or len(username) > 100 or not self.valid_password(password):
            raise AuthError(401, "Invalid username or password")
        with self.db() as db:
            row = db.execute(
                "SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)
            ).fetchone()
            # Non-existent account undergoes comparable KDF work; do not
            # reveal usernames through API errors.
            if row is None:
                self.hash_password(password)
                raise AuthError(401, "Invalid username or password")
            now = time.time()
            if row["locked_until"] > now:
                raise AuthError(429, "Too many attempts. Try again later.")
            digest = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"), row["salt"], row["iterations"]
            )
            if not hmac.compare_digest(digest, row["password_hash"]):
                failures = row["failed_logins"] + 1
                lock = now + LOCK_SECONDS if failures >= MAX_FAILURES else 0
                db.execute("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?",
                           (failures, lock, row["id"]))
                # A raised AuthError exits the transaction context; commit the
                # failed-attempt counter before raising so rate limits persist.
                db.commit()
                raise AuthError(429 if lock else 401,
                                "Too many attempts. Try again later." if lock
                                else "Invalid username or password")
            if row["must_change_password"] and not is_loopback:
                raise AuthError(
                    403,
                    "Initial admin setup requires a localhost connection. "
                    "Use an SSH tunnel, then change the default password."
                )
            db.execute("UPDATE users SET failed_logins=0, locked_until=0 WHERE id=?",
                       (row["id"],))
            db.execute("DELETE FROM sessions WHERE expires_at<=?", (now,))
            token = secrets.token_urlsafe(48)
            db.execute(
                "INSERT INTO sessions(token_hash, user_id, created_at, expires_at) "
                "VALUES(?, ?, ?, ?)",
                (self.token_hash(token), row["id"], now, now + SESSION_TTL)
            )
            return {"access_token": token, "expires_in": SESSION_TTL,
                    "user": self.public_user(row)}

    @staticmethod
    def token_hash(token):
        return hashlib.sha256(token.encode("ascii")).hexdigest()

    def current_user(self, token, allow_setup=False):
        if not isinstance(token, str) or not (32 <= len(token) <= 256):
            return None
        try:
            digest = self.token_hash(token)
        except UnicodeEncodeError:
            return None
        with self.db() as db:
            row = db.execute("""
                SELECT users.* FROM sessions
                JOIN users ON users.id=sessions.user_id
                WHERE sessions.token_hash=? AND sessions.expires_at>?
            """, (digest, time.time())).fetchone()
            if row is None or (row["must_change_password"] and not allow_setup):
                return None
            return self.public_user(row)

    def logout(self, token):
        if not isinstance(token, str) or not (32 <= len(token) <= 256):
            return
        try:
            digest = self.token_hash(token)
        except UnicodeEncodeError:
            return
        with self.db() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (digest,))

    def change_password(self, token, current_password, new_password, is_loopback):
        user = self.current_user(token, allow_setup=True)
        if user is None:
            raise AuthError(401, "Session expired. Sign in again.")
        if user["must_change_password"] and not is_loopback:
            raise AuthError(403, "Initial setup must be completed through localhost")
        if not self.valid_password(current_password):
            raise AuthError(400, "Current password is required")
        if not self.valid_password(new_password, 12):
            raise AuthError(400, "New password must contain at least 12 characters")
        if new_password == "admin" or new_password == current_password:
            raise AuthError(400, "Choose a different, non-default password")
        with self.db() as db:
            row = db.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
            check = hashlib.pbkdf2_hmac(
                "sha256", current_password.encode("utf-8"), row["salt"], row["iterations"]
            )
            if not hmac.compare_digest(check, row["password_hash"]):
                raise AuthError(403, "Current password is incorrect")
            salt, digest = self.hash_password(new_password)
            db.execute("""
                UPDATE users SET password_hash=?, salt=?, iterations=?,
                must_change_password=0, failed_logins=0, locked_until=0, updated_at=?
                WHERE id=?
            """, (digest, salt, ITERATIONS, time.time(), user["id"]))
            # Revoke every existing session on password change. Sign in again.
            db.execute("DELETE FROM sessions WHERE user_id=?", (user["id"],))
        return {"changed": True, "login_required": True}
