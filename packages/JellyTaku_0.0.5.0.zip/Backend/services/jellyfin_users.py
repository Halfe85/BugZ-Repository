"""Snapshot of Jellyfin users pushed by the trusted local C# plugin.

Read-only mirror. This is NOT the JellyTaku admin account table and it
must never store or change Jellyfin passwords or security policies.
"""
import os
import re
import sqlite3
from pathlib import Path
import time

GUID = re.compile(r"^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$")


class JellyfinUsers:
    def __init__(self, path):
        self.path = str(Path(path))
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        os.chmod(self.path, 0o600)
        with sqlite3.connect(self.path) as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS jellyfin_users (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    is_admin INTEGER NOT NULL,
                    is_disabled INTEGER NOT NULL,
                    synced_at REAL NOT NULL
                )
            """)

    def replace(self, users):
        if not isinstance(users, list) or len(users) > 10000:
            raise ValueError("Invalid Jellyfin user snapshot")
        rows = []
        for user in users:
            if not isinstance(user, dict):
                raise ValueError("Invalid Jellyfin user")
            uid, name = user.get("id"), user.get("name")
            admin, disabled = user.get("is_admin"), user.get("is_disabled")
            if (not isinstance(uid, str) or not GUID.fullmatch(uid)
                    or not isinstance(name, str) or not 1 <= len(name) <= 128
                    or type(admin) is not bool or type(disabled) is not bool):
                raise ValueError("Invalid Jellyfin user attributes")
            rows.append((uid.lower(), name, int(admin), int(disabled), time.time()))
        with sqlite3.connect(self.path) as db:
            db.execute("DELETE FROM jellyfin_users")
            db.executemany("INSERT INTO jellyfin_users VALUES (?, ?, ?, ?, ?)", rows)
        return {"count": len(rows)}

    def list(self):
        with sqlite3.connect(self.path) as db:
            db.row_factory = sqlite3.Row
            return [
                {"id": row["id"], "name": row["name"],
                 "is_admin": bool(row["is_admin"]),
                 "is_disabled": bool(row["is_disabled"])}
                for row in db.execute(
                    "SELECT * FROM jellyfin_users ORDER BY name COLLATE NOCASE"
                )
            ]
