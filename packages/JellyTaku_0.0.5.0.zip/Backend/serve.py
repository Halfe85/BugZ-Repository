"""JellyTaku bundled Python worker; listens on all IPv4 interfaces by default.

Static admin assets and health are reachable on the listening interface.
Privileged /v1 APIs require a bearer token; without an operator key, remote
management stays locked. Protect the listener behind a LAN firewall or an
authenticated HTTPS reverse proxy. Never port-forward plaintext HTTP.
"""

import base64
import hashlib
import hmac
import ipaddress
import mimetypes
import re
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

# The script is also loaded directly by the existing smoke-test harness.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from retention import RETENTION_DAYS, RetentionStore  # noqa: E402
from selection import select_best  # noqa: E402
from services.catalog import capabilities  # noqa: E402
from services.metadata import provider_status as metadata_status  # noqa: E402
from services.oauth import provider_status as oauth_status  # noqa: E402
from services.scraping import provider_status as scraping_status  # noqa: E402
from services.streaming import capabilities as streaming_capabilities  # noqa: E402
from services.settings import SettingsStore  # noqa: E402
from services.watchlists import WatchlistStore  # noqa: E402
from services.auth import AuthStore, AuthError  # noqa: E402
from services.jellyfin_users import JellyfinUsers  # noqa: E402

MAX_BODY_BYTES = 256 * 1024
DEFAULT_BIND_HOST = "0.0.0.0"

# Angular production builds can inline bootstrapping scripts into index.html.
# Whitelist only the exact built bytes, not arbitrary inline JavaScript. The
# published admin HTML is a trusted build artifact bundled with the plugin.
INLINE_SCRIPT_RE = re.compile(rb"<script\b[^>]*>(.*?)</script\s*>", re.IGNORECASE | re.DOTALL)


def admin_content_security_policy(html_data=b""):
    """Permit Angular's build-generated inline scripts by SHA-256 hash.

    Angular also uses runtime component style tags and inline CSS attributes.
    Inline *styles* are permitted, but inline *scripts* stay restricted to
    explicit build-asset hashes (no unsafe-inline and no unsafe-eval).
    """
    sources = ["'self'"]
    for match in INLINE_SCRIPT_RE.finditer(html_data):
        script = match.group(1)
        if script.strip():
            digest = base64.b64encode(hashlib.sha256(script).digest()).decode("ascii")
            source = "'sha256-{}'".format(digest)
            if source not in sources:
                sources.append(source)
    return (
        "default-src 'self'; script-src {}; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
        "base-uri 'self'; frame-ancestors 'none'"
    ).format(" ".join(sources))


class HealthHandler(BaseHTTPRequestHandler):
    server_version = "JellyTaku/0.2"

    def send_json(self, status, value):
        payload = json.dumps(value, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def bearer(self):
        value = self.headers.get("Authorization", "")
        return value[7:] if value.startswith("Bearer ") else ""

    def internal_rpc(self):
        # The supervisor's per-process key is independent from browser login.
        # Browser admins cannot call the internal Jellyfin-sync API.
        token = getattr(self.server, "api_token", "")
        given = self.bearer()
        return bool(token and given and hmac.compare_digest(token, given))

    def authorized(self):
        if self.internal_rpc():
            return True
        store = getattr(self.server, "auth", None)
        return bool(store and store.current_user(self.bearer()))

    def is_loopback(self):
        return ipaddress.ip_address(self.client_address[0]).is_loopback

    def send_auth_error(self, error):
        self.send_json(error.status, {"error": error.message})

    def static_admin(self, path):
        """Serve only build-generated Angular assets from a fixed directory.

        The operator must provide a separately configured key to edit
        settings. Non-loopback installations need network-level protection.
        """
        if not (path == "/admin" or path == "/admin/" or path.startswith("/admin/")):
            return False
        root = getattr(self.server, "web_root", None)
        if not root or not Path(root).is_dir():
            self.send_json(503, {"error": "Angular dashboard not built"})
            return True
        request_name = path.removeprefix("/admin/").strip("/")
        if not request_name:
            request_name = "index.html"
        # Prevent directory traversal; no directory indexes or symlinks out.
        base = Path(root).resolve()
        requested = (base / request_name).resolve()
        if not requested.is_relative_to(base) or not requested.is_file():
            self.send_json(404, {"error": "asset not found"})
            return True
        data = requested.read_bytes()
        mime = mimetypes.guess_type(requested.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy",
                         admin_content_security_policy(
                             data if requested.name == "index.html" else b""))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return True

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = parsed.path
        if path == "/health":
            self.send_json(200, {"status": "ok", "service": "jellytaku-python"})
            return
        if path == "/v1/auth/status":
            self.send_json(200, self.server.auth.status())
            return
        if path == "/v1/auth/me":
            user = self.server.auth.current_user(self.bearer(), allow_setup=True)
            if user is None:
                self.send_json(401, {"error": "unauthorized"})
            else:
                self.send_json(200, {"user": user})
            return
        if self.static_admin(path):
            return
        routes = {
            "/v1/retained": lambda: {
                "retention_days": RETENTION_DAYS,
                "items": self.server.store.recent(),
            },
            "/v1/services": lambda: {"services": capabilities()},
            "/v1/settings": lambda: {"settings": self.server.settings.get()},
            "/v1/oauth/providers": lambda: {"providers": oauth_status()},
            "/v1/metadata/providers": lambda: {"providers": metadata_status()},
            "/v1/scraping/providers": scraping_status,
            "/v1/streaming/capabilities": streaming_capabilities,
            "/v1/watchlists": lambda: {
                "items": self.server.watchlists.list(
                    parse_qs(parsed.query).get("user_id", [""])[0])
            },
            "/v1/jellyfin/users": lambda: {
                "users": self.server.jellyfin_users.list()
            },
        }
        if path not in routes:
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            self.send_json(200, routes[path]())
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def read_json(self):
        length = self.headers.get("Content-Length", "")
        if not length.isascii() or not length.isdigit() or int(length) > MAX_BODY_BYTES:
            raise ValueError("invalid request length")
        try:
            body = json.loads(self.rfile.read(int(length)).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as ex:
            raise ValueError("invalid JSON payload") from ex
        if not isinstance(body, dict):
            raise ValueError("expected a JSON object")
        return body

    def do_POST(self):
        path = urlsplit(self.path).path
        if path in ("/v1/auth/login", "/v1/auth/logout", "/v1/auth/password"):
            self.auth_post(path)
            return
        if path == "/v1/jellyfin/users/sync":
            if not self.internal_rpc():
                self.send_json(401, {"error": "internal RPC required"})
                return
            try:
                body = self.read_json()
                self.send_json(200, self.server.jellyfin_users.replace(body.get("users")))
            except ValueError as ex:
                self.send_json(400, {"error": str(ex)})
            return
        paths = ("/v1/sources/best", "/v1/playback/start", "/v1/watchlists")
        if path not in paths:
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            body = self.read_json()
            if path == "/v1/sources/best":
                language = body.get("preferred_language", "sub")
                if not isinstance(language, str) or len(language) > 32:
                    raise ValueError("invalid language")
                selected = select_best(body.get("sources"), language)
                if selected is None:
                    self.send_json(404, {"error": "no compatible source found"})
                else:
                    self.send_json(200, {"selected": selected})
            elif path == "/v1/watchlists":
                self.send_json(200, {"entry": self.server.watchlists.upsert(
                    body.get("user_id"), body.get("anime_id"),
                    body.get("title"), body.get("state"))})
            else:
                item = self.server.store.mark_streamed(
                    body.get("item_id"), body.get("title"))
                self.send_json(200, {"retained": item, "retention_days": RETENTION_DAYS})
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def auth_post(self, path):
        try:
            if path == "/v1/auth/logout":
                token = self.bearer()
                if not self.server.auth.current_user(token, allow_setup=True):
                    self.send_json(401, {"error": "unauthorized"})
                    return
                self.server.auth.logout(token)
                self.send_json(200, {"logged_out": True})
                return
            body = self.read_json()
            if path == "/v1/auth/login":
                result = self.server.auth.login(
                    body.get("username"), body.get("password"), self.is_loopback()
                )
            else:
                result = self.server.auth.change_password(
                    self.bearer(), body.get("current_password"),
                    body.get("new_password"), self.is_loopback()
                )
            self.send_json(200, result)
        except AuthError as ex:
            self.send_auth_error(ex)
        except ValueError as ex:
            self.send_json(400, {"error": str(ex)})

    def do_PUT(self):
        if urlsplit(self.path).path != "/v1/settings":
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            body = self.read_json()
            self.send_json(200, {"settings": self.server.settings.update(body)})
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def log_message(self, format_string, *args):
        print("http: " + format_string % args, file=sys.stderr, flush=True)


def monitor_input(server, stream):
    """Graceful shutdown signal from the plugin's private stdin pipe."""
    for line in stream:
        if line.strip() == "stop":
            server.shutdown()
            return


def validate_bind_address(host):
    """Accept an IPv4 bind address, including 0.0.0.0 and loopback."""
    try:
        address = ipaddress.ip_address(host)
    except ValueError as exc:
        raise ValueError("JELLYTAKU_BIND_HOST must be an IPv4 address") from exc
    if not isinstance(address, ipaddress.IPv4Address):
        raise ValueError("JELLYTAKU_BIND_HOST must be an IPv4 address")
    return str(address)


def main():
    port = int(os.environ.get("JELLYTAKU_PORT", "8097"))
    if not (1 <= port <= 65535):
        raise ValueError("JELLYTAKU_PORT must be within 1..65535")

    data_dir = Path(os.environ.get("JELLYTAKU_DATA_DIR",
                                  str(Path.home() / ".local/share/jellytaku")))
    store = RetentionStore(data_dir / "recently_streamed.sqlite3")
    store.prune()
    # The internal RPC endpoint remains loopback even if the listener accepts
    # LAN connections. The old operator key is retired in favour of SQLite
    # admin credentials and short-lived, revocable bearer sessions.
    bind_host = validate_bind_address(
        os.environ.get("JELLYTAKU_BIND_HOST", DEFAULT_BIND_HOST)
    )
    server = ThreadingHTTPServer((bind_host, port), HealthHandler)
    server.store = store
    server.settings = SettingsStore(data_dir / "backend_settings.sqlite3")
    server.watchlists = WatchlistStore(data_dir / "watchlists.sqlite3")
    server.auth = AuthStore(
        data_dir / "auth.sqlite3",
        Path(__file__).resolve().parent / "bootstrap_admin.json"
    )
    server.jellyfin_users = JellyfinUsers(data_dir / "jellyfin_users.sqlite3")
    server.web_root = Path(os.environ.get(
        "JELLYTAKU_WEB_ROOT", str(Path(__file__).resolve().parent / "wwwroot")))
    server.api_token = os.environ.get("JELLYTAKU_API_KEY", "")
    # Internal RPC key is never sent to Angular; browser uses login sessions.

    thread = threading.Thread(target=monitor_input, args=(server, sys.stdin), daemon=True)
    thread.start()
    print("JellyTaku backend listening on {}:{}".format(bind_host, port), flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
