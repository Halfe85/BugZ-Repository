"""Private, loopback-only JellyTaku worker.

The Python worker is bundled with the C# plugin. Privileged endpoints require
a per-process secret sent by the C# supervisor, never over a public interface.
"""

import hmac
import mimetypes
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

# The script is also loaded directly by the existing smoke-test harness.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from retention import RETENTION_DAYS, RetentionStore  # noqa: E402
from selection import select_best  # noqa: E402
from services.catalog import capabilities  # noqa: E402
from services.metadata import provider_status as metadata_status  # noqa: E402
from services.oauth import provider_status as oauth_status  # noqa: E402
from services.scraping import provider_status as scraping_status  # noqa: E402
from services.streaming import capabilities as streaming_capabilities  # noqa: E402
from services.settings import SettingsStore  # noqa: E402
from services.watchlists import WatchlistStore  # noqa: E402

MAX_BODY_BYTES = 256 * 1024


class HealthHandler(BaseHTTPRequestHandler):
    server_version = "JellyTaku/0.2"

    def send_json(self, status, value):
        payload = json.dumps(value, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def authorized(self):
        # Internal token from the supervised process or separately configured
        # operator secret. Neither is exposed in any HTML or status JSON.
        expected = [
            getattr(self.server, "api_token", ""),
            getattr(self.server, "admin_token", ""),
        ]
        given = self.headers.get("Authorization", "")
        return any(token and hmac.compare_digest(given, "Bearer " + token)
                   for token in expected)

    def static_admin(self, path):
        """Serve only build-generated Angular assets from a fixed directory.

        The Angular app is intentionally not exposed on the network. The
        operator must provide a separately configured key to edit settings.
        """
        if not (path == "/admin" or path == "/admin/" or path.startswith("/admin/")):
            return False
        root = getattr(self.server, "web_root", None)
        if not root or not Path(root).is_dir():
            self.send_json(503, {"error": "Angular dashboard not built"})
            return True
        request_name = path.removeprefix("/admin/").strip("/")
        if not request_name:
            request_name = "index.html"
        # Prevent directory traversal; no directory indexes or symlinks out.
        base = Path(root).resolve()
        requested = (base / request_name).resolve()
        if not requested.is_relative_to(base) or not requested.is_file():
            self.send_json(404, {"error": "asset not found"})
            return True
        data = requested.read_bytes()
        mime = mimetypes.guess_type(requested.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; script-src 'self'; style-src 'self'; "
                         "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
                         "base-uri 'self'; frame-ancestors 'none'")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return True

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = parsed.path
        if path == "/health":
            self.send_json(200, {"status": "ok", "service": "jellytaku-python"})
            return
        if self.static_admin(path):
            return
        routes = {
            "/v1/retained": lambda: {
                "retention_days": RETENTION_DAYS,
                "items": self.server.store.recent(),
            },
            "/v1/services": lambda: {"services": capabilities()},
            "/v1/settings": lambda: {"settings": self.server.settings.get()},
            "/v1/oauth/providers": lambda: {"providers": oauth_status()},
            "/v1/metadata/providers": lambda: {"providers": metadata_status()},
            "/v1/scraping/providers": scraping_status,
            "/v1/streaming/capabilities": streaming_capabilities,
            "/v1/watchlists": lambda: {
                "items": self.server.watchlists.list(
                    parse_qs(parsed.query).get("user_id", [""])[0])
            },
        }
        if path not in routes:
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            self.send_json(200, routes[path]())
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def read_json(self):
        length = self.headers.get("Content-Length", "")
        if not length.isascii() or not length.isdigit() or int(length) > MAX_BODY_BYTES:
            raise ValueError("invalid request length")
        try:
            body = json.loads(self.rfile.read(int(length)).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as ex:
            raise ValueError("invalid JSON payload") from ex
        if not isinstance(body, dict):
            raise ValueError("expected a JSON object")
        return body

    def do_POST(self):
        paths = ("/v1/sources/best", "/v1/playback/start", "/v1/watchlists")
        if urlsplit(self.path).path not in paths:
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            body = self.read_json()
            path = urlsplit(self.path).path
            if path == "/v1/sources/best":
                language = body.get("preferred_language", "sub")
                if not isinstance(language, str) or len(language) > 32:
                    raise ValueError("invalid language")
                selected = select_best(body.get("sources"), language)
                if selected is None:
                    self.send_json(404, {"error": "no compatible source found"})
                else:
                    self.send_json(200, {"selected": selected})
            elif path == "/v1/watchlists":
                self.send_json(200, {"entry": self.server.watchlists.upsert(
                    body.get("user_id"), body.get("anime_id"),
                    body.get("title"), body.get("state"))})
            else:
                item = self.server.store.mark_streamed(
                    body.get("item_id"), body.get("title"))
                self.send_json(200, {"retained": item, "retention_days": RETENTION_DAYS})
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def do_PUT(self):
        if urlsplit(self.path).path != "/v1/settings":
            self.send_json(404, {"error": "not found"})
            return
        if not self.authorized():
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            body = self.read_json()
            self.send_json(200, {"settings": self.server.settings.update(body)})
        except AttributeError:
            self.send_json(503, {"error": "service unavailable"})
        except (ValueError, TypeError) as ex:
            self.send_json(400, {"error": str(ex)})

    def log_message(self, format_string, *args):
        print("http: " + format_string % args, file=sys.stderr, flush=True)


def monitor_input(server, stream):
    """Graceful shutdown signal from the plugin's private stdin pipe."""
    for line in stream:
        if line.strip() == "stop":
            server.shutdown()
            return


def main():
    port = int(os.environ.get("JELLYTAKU_PORT", "8097"))
    if not (1 <= port <= 65535):
        raise ValueError("JELLYTAKU_PORT must be within 1..65535")

    data_dir = Path(os.environ.get("JELLYTAKU_DATA_DIR",
                                  str(Path.home() / ".local/share/jellytaku")))
    store = RetentionStore(data_dir / "recently_streamed.sqlite3")
    store.prune()
    # Binding to loopback is deliberate. The token never goes in logs.
    server = ThreadingHTTPServer(("127.0.0.1", port), HealthHandler)
    server.store = store
    server.settings = SettingsStore(data_dir / "backend_settings.sqlite3")
    server.watchlists = WatchlistStore(data_dir / "watchlists.sqlite3")
    server.web_root = Path(os.environ.get(
        "JELLYTAKU_WEB_ROOT", str(Path(__file__).resolve().parent / "wwwroot")))
    server.api_token = os.environ.get("JELLYTAKU_API_KEY", "")
    # Operator key configured through Jellyfin's plugin settings. The
    # per-process RPC token must NEVER be sent to Angular.
    server.admin_token = os.environ.get("JELLYTAKU_ADMIN_KEY", "")

    thread = threading.Thread(target=monitor_input, args=(server, sys.stdin), daemon=True)
    thread.start()
    print("JellyTaku backend listening on 127.0.0.1:{}".format(port), flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
