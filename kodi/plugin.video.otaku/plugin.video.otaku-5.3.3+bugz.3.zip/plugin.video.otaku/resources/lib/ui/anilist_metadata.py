"""Bounded recovery and diagnostics for public AniList show metadata requests."""
import json
import os
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import xbmc
from resources.lib.ui import client, control

ENDPOINT = 'https://graphql.anilist.co'
_RETRYABLE = (0, 408, 429, 500, 502, 503, 504)


def _header(response, name):
    return next((str(value) for key, value in (getattr(response, 'headers', {}) or {}).items()
                 if key.lower() == name.lower()), '')


def _failure(variables, attempt, reason, response=None):
    record = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'event': 'anilist_metadata_failed', 'endpoint': ENDPOINT,
        'mal_id': variables.get('idMal'), 'attempt': attempt, 'reason': reason,
        'status': getattr(response, 'status_code', 0),
        'content_type': _header(response, 'Content-Type'),
        'retry_after': _header(response, 'Retry-After'),
        'body_prefix': str(getattr(response, 'text', '') or '')[:512],
    }
    control.log('AniList metadata: {reason}; status={status}; attempt={attempt}'.format(**record), level='warning')
    try:
        os.makedirs(control.dataPath, exist_ok=True)
        with open(os.path.join(control.dataPath, 'anilist-metadata.log'), 'a', encoding='utf-8') as output:
            output.write(json.dumps(record, ensure_ascii=False) + '\n')
    except OSError:
        pass


def _retry_delay(response, fallback):
    value = _header(response, 'Retry-After')
    if not value:
        return fallback
    try:
        return max(0.0, float(value))
    except ValueError:
        try:
            return max(0.0, parsedate_to_datetime(value).timestamp() - time.time())
        except (ValueError, TypeError, OverflowError):
            return fallback


def fetch_media(query, variables):
    """Retry temporary failures twice; return None without caching failed data."""
    monitor = xbmc.Monitor()
    for attempt in range(1, 4):
        if monitor.abortRequested():
            return None
        response = None
        try:
            response = client.post(ENDPOINT, json_data={'query': query, 'variables': variables},
                                   headers={'Accept': 'application/json'}, timeout=10)
            status = getattr(response, 'status_code', 0)
            if not 200 <= status < 300:
                _failure(variables, attempt, 'HTTP request failed', response)
                if status not in _RETRYABLE:
                    return None
            else:
                try:
                    payload = response.json()
                    if not isinstance(payload, dict):
                        raise ValueError('Expected a JSON object')
                except (ValueError, TypeError) as exc:
                    _failure(variables, attempt, 'Invalid JSON: ' + str(exc), response)
                else:
                    if payload.get('errors'):
                        _failure(variables, attempt, 'AniList GraphQL error', response)
                        return None
                    data = payload.get('data')
                    media = data.get('Media') if isinstance(data, dict) else None
                    if isinstance(media, dict) and media.get('idMal'):
                        return media
                    _failure(variables, attempt, 'Response contains no usable show metadata', response)
                    return None
        except Exception as exc:
            _failure(variables, attempt, 'Request exception: ' + type(exc).__name__, response)
        if attempt == 3:
            break
        delay = _retry_delay(response, attempt)
        # A long server cooldown belongs to a later user retry, not a frozen GUI.
        if delay > 5:
            control.log('AniList metadata: server cooldown exceeds immediate retry budget', level='warning')
            return None
        if monitor.waitForAbort(delay):
            return None
    return None
