"""Megaplay wire format adapted to Otaku; no Jellytaku runtime required.

AES and CDN token parameters match Megaplay's e1-player.min.js v1.8.112.
They are public player constants, not user credentials. Kodi's bundled pyaes
implements the browser's AES-CBC/PKCS7 operation without new dependencies.
"""

import base64
import hashlib
import hmac
import json
import re
import time
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from resources.lib.ui.pyaes import AESModeOfOperationCBC, Decrypter

_KEY = b'i?LMTAx0Q6,:}50U'.ljust(32, b'\0')
_IV = b"W0;27ToaUpl_P%'c"
_CDN_KEY = b'MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s'

# Order is Otaku's general.subtitles setting. Aliases cover metadata and URLs.
_LANGUAGES = (
    ('none',), ('eng', 'en', 'english'), ('jpn', 'ja', 'japanese'),
    ('spa', 'es', 'spanish'), ('fre', 'fr', 'fra', 'french'),
    ('ger', 'de', 'deu', 'german'), ('ita', 'it', 'italian'),
    ('dut', 'nl', 'nld', 'dutch'), ('rus', 'ru', 'russian'),
    ('por', 'pt', 'portuguese'), ('kor', 'ko', 'korean'),
    ('chi', 'zh', 'zho', 'chinese'), ('ara', 'ar', 'arabic'),
    ('hin', 'hi', 'hindi'), ('tur', 'tr', 'turkish'),
    ('pol', 'pl', 'polish'), ('swe', 'sv', 'swedish'),
    ('nor', 'no', 'nb', 'nn', 'nob', 'nno', 'norwegian'),
    ('dan', 'da', 'danish'), ('fin', 'fi', 'finnish'),
    ('ind', 'id', 'indonesian'), ('may', 'ms', 'msa', 'malay'),
    ('tha', 'th', 'thai'), ('vie', 'vi', 'vietnamese'),
)


def decode_sources(payload):
    if not isinstance(payload, dict):
        raise ValueError('Megaplay response must be an object')
    sources = payload.get('sources')
    if payload.get('enc'):
        encoded = payload['enc']
        ciphertext = base64.b64decode(encoded + '=' * (-len(encoded) % 4),
                                      altchars=b'-_', validate=True)
        if not ciphertext or len(ciphertext) % 16:
            raise ValueError('Invalid Megaplay encrypted source length')
        decryptor = Decrypter(AESModeOfOperationCBC(_KEY, iv=_IV))
        raw = decryptor.feed(ciphertext) + decryptor.feed()
        sources = json.loads(raw.decode('utf-8'))
    if not isinstance(sources, dict) or not isinstance(sources.get('file'), str) or not sources['file']:
        raise ValueError('Megaplay source payload contains no HLS URL')
    url = sources['file']
    parts = urlsplit(url)
    if parts.scheme not in ('http', 'https') or not parts.netloc:
        raise ValueError('Invalid Megaplay stream URL')
    return url


def signed_url(url, now=None):
    """Attach the player's 90-second token; preserve server-supplied tokens."""
    parts = urlsplit(url)
    query = parse_qsl(parts.query, keep_blank_values=True)
    if any(key == 'token' for key, _ in query):
        return url
    match = re.search(r'/([a-f0-9]{32})/([a-f0-9]{32})/', parts.path, re.I)
    if not match:
        return url
    path_key = '/'.join(match.groups()).lower()
    payload = ('{0}|{1}'.format(int(time.time() if now is None else now) + 90, path_key)).encode()
    encode = lambda value: base64.urlsafe_b64encode(value).decode('ascii').rstrip('=')
    token = encode(payload) + '.' + encode(hmac.new(_CDN_KEY, payload, hashlib.sha256).digest())
    return urlunsplit(parts._replace(query=urlencode(query + [('token', token)])))


def playback_link(source):
    """Sign at selection time, not when Otaku cached/displayed this source."""
    link = source['hash']
    if source.get('provider') == 'animepahe' and source.get('megaplay_url'):
        _, separator, headers = link.partition('|')
        return signed_url(source['megaplay_url']) + separator + headers
    return link


def track_language(track):
    # Prefer explicit language metadata, then the label, then the filename.
    for text in (track.get('language') or track.get('lang') or track.get('srclang'),
                 track.get('label'), urlsplit(str(track.get('file') or '')).path):
        if not text:
            continue
        text = str(text).casefold()
        for aliases in _LANGUAGES[1:]:
            if any(re.search(r'(?<![a-z])' + re.escape(alias) + r'(?![a-z])', text)
                   for alias in aliases):
                return aliases[0]
    return 'und'


def ordered_subtitles(tracks, preference):
    """Keep all tracks; requested language, English, default, then first.

Kodi applies its own enabled/disabled, audio, and keyword preferences at play.
Original labels preserve regional variants in Kodi's subtitle selection menu.
"""
    captions = [track for track in tracks if isinstance(track, dict) and track.get('file')
                and (str(track.get('kind', '')).casefold() in ('captions', 'subtitles')
                     or 'sub' in str(track.get('label', '')).casefold())]
    requested = _LANGUAGES[preference][0] if 0 < preference < 20 else 'eng'
    def priority(track):
        language = track_language(track)
        return (0 if language == requested else 1 if language == 'eng' else
                2 if track.get('default') else 3, not bool(track.get('default')))
    return sorted(captions, key=priority)
