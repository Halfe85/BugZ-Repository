"""Otaku's AnimePahe slot, backed by the supplied Megaplay server flow.

The embed parser and getSourcesNew share one cookie-aware HTTP opener.
Kodi receives HLS and subtitle URLs and handles playback itself.
"""

import http.cookiejar
import json
import os
import pickle
import re
import threading
import time
import traceback
from datetime import datetime, timezone
import urllib.error
import urllib.parse
import urllib.request

from resources.lib.ui import control, database
from resources.lib.ui.BrowserBase import BrowserBase
from resources.lib.ui.animepahe_megaplay import decode_sources, signed_url, ordered_subtitles, track_language


class Sources(BrowserBase):
    _BASE_URL = 'https://megaplay.buzz'
    _USER_AGENT = (
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'
    )

    def get_sources(self, mal_id, episode):
        self._log('lookup_start', mal_id=mal_id, episode=episode)
        try:
            mal_id, episode = int(mal_id), int(episode)
            if mal_id <= 0 or episode <= 0:
                self._log('invalid_input', mal_id=mal_id, episode=episode)
                return []
        except (TypeError, ValueError):
            self._log('invalid_input', mal_id=mal_id, episode=episode)
            return []

        title = 'MAL {0}'.format(mal_id)
        try:
            show = database.get_show(mal_id)
            meta = pickle.loads(show['kodi_meta']) if show else {}
            title = self._clean_title(meta.get('name') or title)
        except Exception:
            self._log('title_lookup_failed', traceback=traceback.format_exc())
            control.log('AnimePahe/Megaplay: using MAL ID as title', level='info')

        candidates = []
        try:
            ids = database.get_unique_ids(mal_id, 'mal_id') or {}
            anilist_id = int(ids.get('anilist_id') or 0)
            if anilist_id > 0:
                candidates.append(('ani', anilist_id))
        except Exception:
            self._log('id_mapping_failed', traceback=traceback.format_exc())
        candidates.append(('mal', mal_id))

        preference = control.getInt('general.source')
        langs = ['sub'] if preference == 1 else ['dub'] if preference == 2 else ['sub', 'dub']
        self._log('lookup_plan', title=title, candidates=candidates, languages=langs)
        sources = []
        for lang in langs:
            for identifier_type, identifier in candidates:
                try:
                    sources.append(self._resolve(identifier, episode, title, lang, identifier_type))
                    break
                except Exception as exc:
                    self._log('route_failed', identifier_type=identifier_type,
                              identifier=identifier, episode=episode, language=lang,
                              error=str(exc), traceback=traceback.format_exc())
                    control.log('AnimePahe/Megaplay: {0} {1} failed ({2})'.format(
                        identifier_type, lang, type(exc).__name__), level='warning')
        self._log('lookup_complete', source_count=len(sources))
        return sources

    def _resolve(self, identifier, episode, title, lang, identifier_type='mal'):
        # A private session per audio route prevents concurrent providers from
        # replacing its cookies. Only Python's standard library is required.
        cookies = http.cookiejar.CookieJar()
        session = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))
        session.addheaders = [
            ('User-Agent', self._USER_AGENT),
            ('Accept-Language', 'en-US,en;q=0.9'),
        ]
        self._log('route_start', session=hex(id(session)), identifier_type=identifier_type,
                  identifier=identifier, episode=episode, language=lang)
        embed_url = '{0}/stream/{1}/{2}/{3}/{4}'.format(
            self._BASE_URL, identifier_type, identifier, episode, lang)
        html, embed_url = self._get(session, embed_url, {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Referer': 'https://anikoto.cz/',
        })
        player = re.search(r'data-id=["\'](\d+)["\']', html)
        if player is None:
            raise ValueError('Megaplay embed contains no player ID')
        self._log('player_found', player_id=player.group(1), embed_url=embed_url,
                  session=hex(id(session)), cookie_names=[cookie.name for cookie in cookies])

        # The repeated id parameter is intentional, matching the supplied script.
        query = urllib.parse.urlencode([('id', player.group(1)), ('id', player.group(1))])
        raw, _ = self._get(session, self._BASE_URL + '/stream/getSourcesNew?' + query, {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': embed_url,
            'Sec-Fetch-Site': 'same-origin',
        })
        payload = json.loads(raw)
        self._log('source_payload', keys=list(payload) if isinstance(payload, dict) else None,
                  has_encoded_stream=bool(payload.get('enc')) if isinstance(payload, dict) else False)
        video_url = decode_sources(payload)
        self._log('source_decoded', video_url=video_url, encoded=bool(payload.get('enc')))

        headers = self._playback_headers(cookies, video_url)
        quality = 0
        try:
            playlist, _ = self._get(session, signed_url(video_url), headers)
            heights = [int(h) for h in re.findall(r'RESOLUTION=\d+x(\d+)', playlist)]
            if heights:
                height = max(heights)
                quality = 1 if height <= 480 else 2 if height <= 720 else 3 if height <= 1080 else 4
        except Exception:
            # Kodi can still try playback if the optional quality probe fails.
            self._log('quality_probe_failed', traceback=traceback.format_exc())

        source = {
            'release_title': '{0} - Ep {1}'.format(title, episode),
            'hash': video_url + '|' + urllib.parse.urlencode(self._playback_headers(cookies, video_url)),
            'type': 'direct',
            'megaplay_url': video_url,
            'quality': quality,
            'debrid_provider': '',
            'provider': 'animepahe',
            'size': 'NA',
            'seeders': 0,
            'byte_size': 0,
            'info': ['animepahe ' + lang.upper()],
            'lang': 3 if lang == 'dub' else 2,
            'channel': 3,
            'sub': 1,
        }
        subs = []
        tracks = ordered_subtitles(payload.get('tracks') or [], control.getInt('general.subtitles'))
        for index, track in enumerate(tracks):
            url = urllib.parse.urljoin(embed_url, track['file'])
            label = track.get('label') or track.get('language') or 'Unknown'
            subs.append({
                'url': url, 'file': url, 'lang': track_language(track), 'name': label, 'index': index,
                'headers': self._playback_headers(cookies, url),
            })
        if subs:
            source['subs'] = subs
        self._log('subtitle_selection', preference=control.getInt('general.subtitles'),
                  tracks=[{'language': sub['lang'], 'name': sub['name']} for sub in subs])
        self._log('source_ready', video_url=video_url, quality=quality,
                  subtitle_count=len(subs), language=lang)
        return source

    def _get(self, session, url, headers):
        request = urllib.request.Request(url, headers=headers)
        started = time.monotonic()
        self._log('http_request', session=hex(id(session)), url=url,
                  headers=self._log_headers(dict(session.addheaders, **headers)))
        try:
            with session.open(request, timeout=15) as response:
                body = response.read().decode('utf-8', errors='replace')
                self._log('http_response', session=hex(id(session)), requested_url=url,
                          final_url=response.geturl(), status=response.status,
                          elapsed_ms=round((time.monotonic() - started) * 1000),
                          headers=self._log_headers(dict(response.headers)),
                          body=body[:65536], body_length=len(body), truncated=len(body) > 65536)
                return body, response.geturl()
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read(65537).decode('utf-8', errors='replace')
                self._log('http_error', session=hex(id(session)), requested_url=url,
                          final_url=exc.geturl(), status=exc.code, error=str(exc),
                          headers=self._log_headers(dict(exc.headers)),
                          body=body[:65536], truncated=len(body) > 65536,
                          traceback=traceback.format_exc())
            finally:
                exc.close()
            raise
        except Exception as exc:
            self._log('http_failed', session=hex(id(session)), url=url,
                      error=str(exc), traceback=traceback.format_exc())
            raise

    @staticmethod
    def _log_headers(headers):
        return {key: '<redacted>' if key.lower() in (
            'cookie', 'set-cookie', 'authorization', 'proxy-authorization') else value
            for key, value in headers.items()}

    def _log(self, event, **fields):
        """Append one JSON record without depending on Kodi's debug setting."""
        try:
            os.makedirs(control.dataPath, exist_ok=True)
            record = dict(timestamp=datetime.now(timezone.utc).isoformat(),
                          pid=os.getpid(), thread=threading.get_ident(),
                          provider_instance=hex(id(self)), event=event, **fields)
            path = os.path.join(control.dataPath, 'animepahe-megaplay.log')
            with open(path, 'a', encoding='utf-8') as output:
                output.write(json.dumps(record, ensure_ascii=False, default=str) + '\n')
        except Exception as exc:
            # Logging must never turn a usable source into a failed scrape.
            if not getattr(self, '_log_failure_reported', False):
                self._log_failure_reported = True
                control.log('AnimePahe/Megaplay: cannot write diagnostic log ({0})'.format(exc),
                            level='warning')

    def _playback_headers(self, cookies, url):
        headers = {
            'User-Agent': self._USER_AGENT,
            'Referer': self._BASE_URL + '/',
            'Origin': self._BASE_URL,
        }
        # Export only cookies applicable to this URL, never all session cookies
        # to an unrelated video or subtitle CDN.
        request = urllib.request.Request(url)
        cookies.add_cookie_header(request)
        if request.has_header('Cookie'):
            headers['Cookie'] = request.get_header('Cookie')
        return headers
